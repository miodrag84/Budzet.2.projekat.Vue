



<template>
<div class="bottom">
            <div class="add">
                <div class="add__container">

                    <input type="text" v-model="description" class="add__description" placeholder="Income description">
                    <input type="number"  v-model="number" class="add__value" placeholder="Value">
                    <button class="add__btn" @click="saveDescription">
                    <i class="ion-ios-checkmark-outline"></i></button>
                    <input type="text" v-model="minusDescription" class="add__description" placeholder="Expenses description">
                    <input type="number"  v-model="minusNumber" class="add__value" placeholder="Value">
                    <button class="add__btn" @click="saveDescriptionMinus">
                    <i class="ion-ios-checkmark-outline"></i></button>
                </div>
            </div>
             
            
        </div>

</template>
<script>
import { mapActions } from 'vuex';
import * as Types from '../store/types/types';
export default {
   data() {
       return {
       description: '',
       number: '',
       minusDescription: '',
       minusNumber: '',

       }
   },
   methods: {
       ...mapActions({
          addDescription: Types.ADD_DESCRIPTION,
          addNumber: Types.ADD_NUMBER,
          addMinusDescription: Types.ADD_MINUS_DESCRIPTION,
          addMinusNumber: Types.ADD_MINUS_NUMBER,
       }),

   saveDescription() {
        const data = {
             description: this.description,
             number: this.number
             }
            //  if(!this.description) this.addDescription = true;
            //  if(this.description) this.addDescription = false;
            //  if(!this.number) this.addNumber = true;
            //  if(this.number) this.addNumber = false;
         this.addDescription(data);
         this.addNumber(data);
               this.description = '';
               this.number = '';
   },
   saveDescriptionMinus() {
        const dataMinus = {
             minusDescription: this.minusDescription,
             minusNumber: this.minusNumber
             }
            //  if(this.minusDescription == '') this.addMinusDescription = false;
            //  if(this.minusDescription !== '') this.addMinusDescription = true;
            //  if(this.minusNumber == '') this.addMinusNumber = false;
            //  if(this.minusNumber !== '') this.addMinusNumber = true;
          this.addMinusDescription(dataMinus);
          this.addMinusNumber(dataMinus);     
                this.minusDescription = '';
                this.minusNumber = '';
   }
   }
}

</script>