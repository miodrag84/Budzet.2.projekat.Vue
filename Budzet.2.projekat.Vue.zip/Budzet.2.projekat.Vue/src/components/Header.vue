



<template>
       <div class="top">
            <div class="budget">
                <div class="budget__title">
                    Available Budget in <span class="budget__title--month">November</span>:
                </div>
                
                <div class="budget__value">Total: {{ total }}</div>
                
                <div class="budget__income clearfix">
                    <div class="budget__income--text">Income</div>
                    <div class="right">
                        <div class="budget__income--value">+ {{ totalPlus }}</div>
                        <div class="budget__income--percentage">&nbsp;</div>
                    </div>
                </div>
                
                <div class="budget__expenses clearfix">
                    <div class="budget__expenses--text">Expenses</div>
                    <div class="right clearfix">
                        <div class="budget__expenses--value">- {{ totalMinus }}
                        </div>
                        <div class="budget__expenses--percentage">{{ percent }}</div>
                    </div>
                </div>
            </div>
        </div>

</template>
<script>
import { mapState } from 'vuex';
import * as Types from '../store/types/types';
export default {

        computed: {
            
            totalPlus() {
              let sum = 0;
              this.number.forEach(function(item) {
              sum += (parseFloat(item));
              })
              return sum;
            },
            totalMinus() {
              let sum = 0;
              this.minusNumber.forEach(function(item) {
              sum += (parseFloat(item));
              })
              return sum;
            },
            total() {
              let sum = 0;
              let t = this.totalPlus -= this.totalMinus;
              sum += t;
              return sum;
            },
            percent() {
              let sum = "";
              if(this.total > 0) {
              let p = Math.round((this.totalMinus / this.totalPlus) * 100) + '%';
              sum += p;
              return sum;
              }
              else { let p = ""}
            },

         ...mapState({
            description: state => state.description,
            number: state => state.number,
            minusDescription: state => state.minusDescription,
            minusNumber: state => state.minusNumber,

    }),
    },
    methods: {

            
    }
}
</script>