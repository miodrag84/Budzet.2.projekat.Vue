



<template>
    <div class="container ">
                
            <div class="row" style="float:left; width:40%;">
                <h5 class="icome__title">Income</h5>
                <div class="col-md-5">
                    <ul>
                       <li
                       
                       v-for="item in description"
                       :key="item.id"
                       >
                       <div> 
                         {{ item }} 
                         </div>
                         <br/><br/>
                       </li>
                    </ul>
                </div>

                <div class="col-md-3 col-md-offset-1">
                    <ul>
                       <li
                       v-for="num in number"
                       :key="num.id"
                       >
                         <div style="color:blue;"> 
                            
                         {{ '+' + '' + num }} 
                            
                           </div>
                         <br/><br/>
                      </li>

                    </ul> 
                </div>
            </div>         
                   
            <div class="row" style="float:right; margin-right:40%;">
                <h5 class="expenses__title">Expenses</h5>
                <div class="col-md-5">
                    <ul>
                       <li
                       v-for="itemm in minusDescription"
                       :key="itemm.id"
                       >
                         <div>  
                         {{ itemm }} 
                         </div>
                        <br/><br/>
                      </li>
                      </ul>
                </div>
                      
                <div class="col-md-3 col-md-offset-1">
                    <ul>
                      <li
                       v-for="numm in minusNumber"
                       :key="numm.id"
                       >
                         <div style="margin-left:25px; color:red;">   
                         {{ -  numm }} 
                         </div>
                         <br/><br/>
                      </li>
                    </ul> 
                </div> 
                
            </div>
                
    </div>
</template>

<script>
import { mapState } from 'vuex';
import * as Types from '../store/types/types';
export default {

        computed: {
         ...mapState({
            description: state => state.description,
            number: state => state.number,
            minusDescription: state => state.minusDescription,
            minusNumber: state => state.minusNumber,

    }),
    },
}
</script>

<style>
* {
box-sizing: border-box;
margin: 0;
padding: 0;
}
.row::after {
    content: "";
    clear: both;
    display: table;
}
 .col,
 [class*="col-"] {
    float: left;
    padding: 15px;
  }
li {
    display: inline;
}
</style>

