



<template>
    <body>
        <app-header></app-header>
        <app-home></app-home>
        <app-income-expenses></app-income-expenses>

    </body>
</template>

<script>
    import Header from './components/Header.vue';
    import Home from './components/Home.vue';
    import IncomeExpenses from './components/IncomeExpenses.vue';
    import { mapActions } from 'vuex';
    import * as Types from './store/types/types';
    export default {
    
    components: {
      appHeader: Header,
      appHome: Home,
      appIncomeExpenses: IncomeExpenses
        },

    }
</script>

<style>

</style>
