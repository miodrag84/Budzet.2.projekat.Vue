



import * as Types from './types/types';

export default {

  [Types.SET_DESCRIPTION]: (state, payload) => {
    state.description.unshift(payload);
  },
  [Types.SET_NUMBER]: (state, payload) => {
    state.number.unshift(payload);
  },

  
  [Types.SET_MINUS_DESCRIPTION]: (state, payload) => {
    state.minusDescription.unshift(payload);
  },
  [Types.SET_MINUS_NUMBER]: (state, payload) => {
    state.minusNumber.unshift(payload);
  },


}