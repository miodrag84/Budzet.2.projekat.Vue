



import Vue from 'vue';
import * as Types from './types/types';

export default {

    [Types.ADD_DESCRIPTION]: ({ commit }, payload) => {

          commit(Types.SET_DESCRIPTION, payload.description);
       
      },
    [Types.ADD_NUMBER]: ({ commit }, payload) => {

          commit(Types.SET_NUMBER, payload.number);
     
    },

    [Types.ADD_MINUS_DESCRIPTION]: ({ commit }, payload) => {

          commit(Types.SET_MINUS_DESCRIPTION, payload.minusDescription);
        
    },
    [Types.ADD_MINUS_NUMBER]: ({ commit }, payload) => {

          commit(Types.SET_MINUS_NUMBER, payload.minusNumber);
      
   
  },
















}